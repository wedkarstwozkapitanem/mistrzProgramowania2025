#include <iostream>
#include <vector>
#include <set>
#include <limits>
#include <bitset>
#include <algorithm>
#include <unordered_map>

inline std::string usunWiodaceZera(const std::string& binarna) {
    size_t pierwszaJedynka = binarna.find_first_not_of('0');
    return (pierwszaJedynka == std::string::npos) ? "0" : binarna.substr(pierwszaJedynka);
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    unsigned long long n;
    std::cin >> n;

    std::vector<long long> zaszyfrowane(n), klucz(n);
    std::vector<std::string> zaszyfrowaneBinarne(n);

    for (int i = 0; i < n; ++i) {
        std::cin >> zaszyfrowane[i];
        std::bitset<64> liczbaBinarnie(zaszyfrowane[i]);
        zaszyfrowaneBinarne[i] = usunWiodaceZera(liczbaBinarnie.to_string());
    }

    std::unordered_map<long long, std::vector<long long>> binarneKlucz;
    size_t maks_rozmiar{}, min_rozmiar{std::numeric_limits<long long>::max()};
    for (int i = 0; i < n; ++i) {
        std::cin >> klucz[i];
        std::bitset<64> liczbaBinarnie(klucz[i]);
        auto binarka = usunWiodaceZera(liczbaBinarnie.to_string());
        binarneKlucz[binarka.size()].push_back(std::stoll(binarka, nullptr, 2));
        maks_rozmiar = std::max(maks_rozmiar, binarka.size());
        min_rozmiar = std::min(min_rozmiar, binarka.size());
    }

    for (auto& i : binarneKlucz) {
        std::sort(i.second.begin(), i.second.end());
    }


    std::set<int> użyte_klucze;

    for (int i = 0; i < n; ++i) {
        const auto rozmiar = zaszyfrowaneBinarne[i].size();
        long long pi = rozmiar;

        bool znaleziono = false;
        long long maxxor = 0;

        if (binarneKlucz.find(pi) == binarneKlucz.end()) {
            pi = rozmiar;
            while (pi-- <= maks_rozmiar) {
                if (binarneKlucz.find(pi) != binarneKlucz.end()) {
                    znaleziono = true;
                    break;
                }
            }
        }

        if (!znaleziono) {
            pi = rozmiar;
            while (pi++ < maks_rozmiar) {
                if (binarneKlucz.find(pi) != binarneKlucz.end()) {
                    znaleziono = true;
                    break;
                }
            }
        }

        long long maksand = 1000000000;

            for (auto& pix : binarneKlucz[pi]) {
                if (użyte_klucze.find(pix) == użyte_klucze.end()) {
                    if ((zaszyfrowane[i] ^ pix) <= maksand) {
                        maksand = (zaszyfrowane[i] ^ pix);
                        maxxor = zaszyfrowane[i] ^ pix;
                        użyte_klucze.insert(pix); 
                        std::cout << zaszyfrowane[i] << ' ' << pix << '\n';
                    }
                }
             }
       

    }

    return 0;
}
