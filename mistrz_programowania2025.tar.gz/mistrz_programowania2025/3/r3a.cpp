/*
*    nazwa: Siuuuuu
*    autor: Dominik Łempicki Kapitan
*/

#include<iostream>

int main() {
    int n;std::cin >> n;
    std::cout << "Si";
    for(int i{};i<n;++i) std::cout << "u";

    return EXIT_SUCCESS;
}