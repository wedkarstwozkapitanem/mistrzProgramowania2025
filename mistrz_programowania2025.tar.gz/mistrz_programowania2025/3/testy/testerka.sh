#!/bin/bash

# Zmienna przechowująca nazwę pliku źródłowego
NAZWA_PROJEKTU="../r3c.cpp"
NAZWA_WYKONYWALNA="program"

# Kompilowanie programu
echo "Kompilowanie programu..."
g++ -o $NAZWA_WYKONYWALNA $NAZWA_PROJEKTU -std=c++11

# Sprawdzanie czy kompilacja zakończyła się sukcesem
if [ $? -ne 0 ]; then
    echo "Błąd kompilacji! Zakończenie programu."
    exit 1
fi

# Funkcja do generowania losowych danych wejściowych
generate_input() {
    # Parametry
    n=$1
    max_value=$2
    
    # Generowanie danych wejściowych
    echo $n
    for ((i = 0; i < n; i++)); do
        echo -n "$((RANDOM % (2 * max_value + 1) - max_value)) " # Generowanie losowej liczby z zakresu -max_value do max_value
    done
    echo
}

# Funkcja do obliczania sensacyjności na podstawie manualnej logiki
check_manual() {
    input=$1
    n=$(echo "$input" | head -n 1)
    emotions=$(echo "$input" | tail -n 1)

    # Przekształcamy emocje w tablicę
    IFS=' ' read -r -a emotions_array <<< "$emotions"
    
    total_sum=0
    for emotion in "${emotions_array[@]}"; do
        total_sum=$((total_sum + emotion))
    done
    
    # Jeśli suma emocji jest zerowa, próbujemy znaleźć dzielniki sumy
    if [ $total_sum -eq 0 ]; then
        # Jeśli suma jest zerowa, musimy znaleźć podział na 2 lub więcej odcinków
        # Sprawdzamy, czy możemy podzielić tablicę na części o sumie 0
        current_sum=0
        part_count=0
        for emotion in "${emotions_array[@]}"; do
            current_sum=$((current_sum + emotion))
            if [ $current_sum -eq 0 ]; then
                part_count=$((part_count + 1))
                current_sum=0
            fi
        done
        if [ $part_count -ge 2 ]; then
            return 0  # Ok, poprawny podział
        fi
    else
        # Sprawdzamy dzielniki sumy, iterując po wszystkich dzielnikach sumy
        for ((part_sum = 1; part_sum <= total_sum; part_sum++)); do
            # Jeśli suma nie jest podzielna przez part_sum, omijamy
            if [ $((total_sum % part_sum)) -ne 0 ]; then
                continue
            fi
            
            current_sum=0
            part_count=0
            for emotion in "${emotions_array[@]}"; do
                current_sum=$((current_sum + emotion))
                if [ $current_sum -eq $part_sum ]; then
                    part_count=$((part_count + 1))
                    current_sum=0
                fi
            done
            # Jeżeli mamy 2 lub więcej odcinków
            if [ $current_sum -eq 0 ] && [ $part_count -ge 2 ]; then
                return 0  # Ok, poprawny podział
            fi
        done
    fi

    return 1  # Jeśli nic nie znaleziono, zwrócimy błąd
}

# Testy z generowaniem losowych danych
for i in {1..10}; do
    # Generowanie danych
    input=$(generate_input 10 100)
    echo "Test $i:"
    echo "$input"
    
    # Uruchamianie programu na danych
    output=$(echo "$input" | ./$NAZWA_WYKONYWALNA)
    echo "Output programu: $output"

    # Sprawdzanie poprawności
    if check_manual "$input"; then
        if [[ "$output" =~ "TAK" ]]; then
            echo "Wynik OK: poprawny podział"
        else
            echo "Błąd: Program nie znalazł poprawnego podziału"
        fi
    else
        if [[ "$output" =~ "NIE" ]]; then
            echo "Wynik OK: brak podziału"
        else
            echo "Błąd: Program nie zwrócił poprawnej odpowiedzi"
        fi
    fi
    echo "-----------------------------"
done

echo "Testowanie zakończone"
