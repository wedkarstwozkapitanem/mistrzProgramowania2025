
#include <iostream>
#include<bits/stdc++.h>
#include <map>

using ll = long long;
using namespace std;

ll n;
ll ak;

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin>>n;
    vector<ll>v;
    for(int i=0;i<n;i++){
        ll a;
        cin>>a;
        v.push_back(a);
    }
    string odp,pom;
    cin>>odp;
    cin>> pom;
    std::cout << pom << '\n';
    if(pom!=odp){
        cerr<<"I: źle określono możliwość stworzenia podziału";
        return 0;
    }
    ll ile;
ll a=-1;
    if(pom=="Nie"){
cerr<<"C";
return 0;}
//return 0;
    cin>>ile;
if(ile<2){
cerr<<"I: tylko jeden odcinek";
return 0;

}
ak=0;
ll sm=0;
ll diff=0;
    for(int i=0;i<ile;i++){
        //ll a;
        cin>>a;
//a--;
   //     ak=0;
 //       ll sm=0;
       if(a>n){
cerr<<"I: użyto nieistniejącego kawałka";
return 0;
}
if(a==ak){
cerr<<"I: odcinek o długości 0";
return 0;
}
        while(a>ak){
            sm+=v[ak++];
        }
        if(!i)
            diff = sm;
        if(sm!=i*diff +diff){
            cerr<<"I: sumy nie są równe";
            return 0;
        }
        
    }
if(a!=n){
cerr<<"I: nie użyto wszystkich kawałków";
return 0;
}
    cerr<<"C";
    return 0;
}
