#!/bin/bash

# Kolory ANSI
GREEN='\033[0;32m'  # Kolor zielony (Zaliczone)
RED='\033[0;31m'    # Kolor czerwony (Wynik niezaliczony)
NC='\033[0m'        # Kolor domyślny (reset)

# Ścieżka do programu do sprawdzania
PROGRAM="./a.out"

# Folder wejściowy
INPUT_DIR="in"

# Zmienna do przechowywania najdłuższego czasu
max_time=0
max_time_file=""
total_time_sum=0
file_count=0
failed_tests=0

# Iteracja przez wszystkie pliki wejściowe w folderze "in"
for input_file in "$INPUT_DIR"/*.in; do
    # Sprawdzanie, czy plik istnieje
    if [[ ! -e "$input_file" ]]; then
        continue
    fi

    # Zliczanie przetwarzanych plików
    ((file_count++))

    # Wczytanie danych z pliku do zmiennej DANE
    DANE=$(cat "$input_file")

    # Zmierzenie czasu wykonania programu w sekundach
    exec_time=$( { time $PROGRAM < "$input_file" 2>&1; } 2>&1 | grep real | sed 's/real\s*\([0-9]*m\)\([0-9]*\.[0-9]*\)s/\1\2/' | awk -F 'm' '{print $1*60 + $2}' )

    # Zastosowanie 'bc' do obliczeń zmiennoprzecinkowych
    total_time=$(echo "$exec_time" | bc)
    total_time_sum=$(echo "$total_time_sum + $total_time" | bc)

    # Sprawdzanie, czy obecny czas jest największy
    if (( $(echo "$total_time > $max_time" | bc -l) )); then
        max_time=$total_time
        max_time_file="$input_file"
    fi

    # Uruchomienie programu i zapisywanie wyniku
    wynik=$( $PROGRAM < "$input_file" )

    # Połączenie danych wejściowych z wynikiem programu
    DANE="$DANE $wynik"

    # Uruchomienie programu checker i przechwycenie tylko stderr
    wynik_checker=$( "./checker" <<< "$DANE" 2>&1 )

    # Sprawdzanie, czy wynik zawiera dokładnie "C"
    echo -e "\nUruchamiam checker dla pliku: $input_file"
    if [[ "$wynik_checker" == *"C"* ]]; then
        echo -e "${GREEN}Zaliczone${NC}"
    else
        echo -e "$wynik_checker"
        echo -e "${RED}Checker zatrzymany z powodu błędu.${NC}"
        failed_tests=$((failed_tests + 1))
    fi
done

# Obliczanie średniego czasu
if (( file_count > 0 )); then
    avg_time=$(echo "$total_time_sum / $file_count" | bc -l)
else
    avg_time=0
fi

# Podsumowanie
echo -e "\nPodsumowanie:"
echo -e "Liczba przetworzonych plików: $file_count"
echo -e "Średni czas wykonania programu: $avg_time sekund"
echo -e "Najdłuższy czas wykonania programu: $max_time sekund (plik: $max_time_file)"
echo -e "Liczba niezaliczonych testów: $failed_tests"
