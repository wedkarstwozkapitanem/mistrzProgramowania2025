#!/bin/bash

PROGRAM="./a.out"
CHECKER="./checker"
INPUT_DIR="in"

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

max_time=0
file_count=0

for input_file in "$INPUT_DIR"/*.in; do
    if [[ ! -e "$input_file" ]]; then
        continue
    fi

    ((file_count++))

    exec_time=$( { time wynik=$(timeout 5 $PROGRAM < "$input_file"); } 2>&1 | grep real | sed 's/real\s*\([0-9]*m\)\([0-9]*\.[0-9]*\)s/\1\2/' | awk -F 'm' '{print $1*60 + $2}' )

    if [[ $? -eq 124 ]]; then
        echo -e "${RED}a.out przekroczył limit czasu${NC}"
        exit 1
    fi

    total_time=$(echo "$exec_time" | bc)
    if (( $(echo "$total_time > $max_time" | bc -l) )); then
        max_time=$total_time
    fi

    echo -e "\nPrzetworzono plik $file_count: $input_file, czas: $total_time sekund\n"

    wynik_checker=$(echo "$wynik" | timeout 5 $CHECKER)

    if [[ $? -eq 124 ]]; then
        echo -e "${RED}Checker przekroczył limit czasu${NC}"
        exit 1
    fi

    if [[ "$wynik_checker" == *"C"* ]]; then
        echo -e "${GREEN}Zaliczone${NC}"
    else
        echo -e "${RED}Wynik: $wynik_checker${NC}"
        exit 1
    fi
done

echo -e "\nNajdłuższy czas wykonania programu: $max_time sekund\n"
