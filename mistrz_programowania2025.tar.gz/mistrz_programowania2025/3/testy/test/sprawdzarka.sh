#!/bin/bash

PROGRAM="./checker"
INPUT_DIR="in"
OUTPUT_DIR="out"

# Kolory ANSI
GREEN='\033[0;32m'  # Kolor zielony (Zaliczone)
RED='\033[0;31m'    # Kolor czerwony (Wynik niezaliczony)
NC='\033[0m'        # Kolor domyślny (reset)

# Iteracja przez wszystkie pliki w katalogu "out", które kończą się na ".out"
for wynik_file in "$OUTPUT_DIR"/*.out; do
    # Wyciąganie nazwy pliku wejściowego odpowiadającego plikowi wynikowemu
    input_file="$wynik_file"

    # Wypisanie komunikatu w nowej linii
    echo -e "\nUruchamiam checker dla pliku: $input_file"

    # Uruchomienie programu i zapisanie wyników stdout i stderr
    wynik=$( $PROGRAM < "$input_file" 2>&1 )

    # Sprawdzanie, czy wynik zawiera dokładnie "C"
    if [[ "$wynik" == *"C"* ]]; then
        echo -e "${GREEN}Zaliczone${NC}"
    else
        echo -e "${RED}Wynik: $wynik${NC}"
        echo -e "${RED}Checker zatrzymany z powodu błędu.${NC}"
        exit 1  # Zatrzymanie skryptu z kodem błędu
    fi
done
