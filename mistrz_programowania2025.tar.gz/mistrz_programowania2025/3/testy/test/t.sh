#!/bin/bash


executable="./checker"
max_time="2000"

for input_file in $(*.in | sort -n -t. -k1,1); do
    test_number=$(basename "$input_file" .in)

    time_output=$( (time ./$executable < "$input_file" > /dev/null) 2>&1 )
    exit_code=$?

    if [ "$exit_code" -eq 255 ]; then  # -1 in 8-bit unsigned is 255
        echo "$test_number "$'\t'" <- FAILED"
        break
    fi

    real_time=$(echo "$time_output" | grep real | awk '{print $2}')

    minutes=$(echo $real_time | cut -d'm' -f1)
    seconds=$(echo $real_time | cut -d'm' -f2 | cut -d's' -f1)

    seconds=$(echo "$seconds" | sed 's/,/./')

    total_seconds=$(echo "$minutes * 60 + $seconds" | bc)

    if (( $(echo "$total_seconds > $max_time" | bc -l) )); then
        echo "$test_number "$'\t'" $real_time "$'\t'" <- TOO SLOW!"
        break
    fi

    echo "$test_number "$'\t'" $real_time"
done
