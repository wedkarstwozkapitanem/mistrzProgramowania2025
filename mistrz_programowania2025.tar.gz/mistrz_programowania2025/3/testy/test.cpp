#include<iostream>
#include<time.h>

int main() {
    std::srand(time(NULL));
    long long n = 1e4;
    std::cout << n << '\n';
    for(int i{};i<n;++i){
        std::cout << rand() << ' ';
    }
    std::cout << '\n';
    for(int i{};i<n;++i){
        std::cout << rand() << ' ';
    }
}