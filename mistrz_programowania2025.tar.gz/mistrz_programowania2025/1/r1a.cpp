/*
    nazwa:Złość
    autor:Dominik Łempicki Kapitan
*/

#include<iostream>

int main() {
    std::ios_base::sync_with_stdio(0),std::cin.tie(0);
    long long n;std::cin >> n;
    std::cout << n*60;
    return EXIT_SUCCESS;
}