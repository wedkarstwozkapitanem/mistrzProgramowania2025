#!/bin/bash

# Ścieżka do programu do sprawdzania
PROGRAM="./a.out"

# Foldery wejściowe i wyjściowe
INPUT_DIR="in"
OUTPUT_DIR="out"

# Kolory ANSI
GREEN='\033[0;32m'  # Kolor zielony
RED='\033[0;31m'    # Kolor czerwony
YELLOW='\033[0;33m' # Kolor żółty
NC='\033[0m'        # Kolor domyślny (reset)

# Tworzenie folderu wyjściowego, jeśli nie istnieje
mkdir -p "$OUTPUT_DIR"

# Zmienne do przechowywania statystyk
max_time=0
total_time=0
file_count=0
failed_count=0
longest_test=""
longest_time=0

# Iteracja przez wszystkie pliki wejściowe w folderze "in"
for input_file in "$INPUT_DIR"/*.in; do
    # Sprawdzanie, czy plik istnieje
    if [[ ! -e "$input_file" ]]; then
        continue
    fi

    # Zliczanie przetwarzanych plików
    ((file_count++))

    # Wyznaczanie nazwy pliku wyjściowego
    output_file="$OUTPUT_DIR/$(basename "$input_file" .in).out"
    rm -f "$output_file"  # Usuwanie poprzednich plików wyjściowych

    # Kopiowanie całego pliku wejściowego do pliku wyjściowego
    cat "$input_file" > "$output_file"

    # Zmierzenie czasu wykonania programu w sekundach i zapisanie wyjścia do pliku
    exec_time=$( { time $PROGRAM < "$input_file" >> "$output_file" 2>&1; } 2>&1 | grep real | sed 's/real\s*\([0-9]*m\)\([0-9]*\.[0-9]*\)s/\1\2/' | awk -F 'm' '{print $1*60 + $2}' )

    # Zastosowanie 'bc' do obliczeń zmiennoprzecinkowych
    total_time=$(echo "$total_time + $exec_time" | bc)

    # Sprawdzanie, czy obecny czas jest największy
    if (( $(echo "$exec_time > $max_time" | bc -l) )); then
        max_time=$exec_time
        longest_test="$input_file"
        longest_time=$exec_time
    fi

    # Weryfikacja wyniku - sprawdzanie, czy w pliku wyjściowym jest określony rezultat (np. "C")
    if grep -q "C" "$output_file"; then
        echo -e "${GREEN}Zaliczone: $input_file${NC}"
    else
        echo -e "${RED}Nieudane: $input_file${NC}"
        ((failed_count++))
    fi
done

# Obliczanie średniego czasu wykonania
average_time=$(echo "$total_time / $file_count" | bc -l)

# Wyświetlenie podsumowania
echo -e "${YELLOW}\n--- PODSUMOWANIE ---${NC}"
echo -e "${YELLOW}Łączna liczba testów: $file_count${NC}"
echo -e "${RED}Nieudane testy: $failed_count${NC}"
echo -e "${GREEN}Zaliczone testy: $((file_count - failed_count))${NC}"
echo -e "${YELLOW}Łączny czas wykonania: ${total_time}s${NC}"
echo -e "${YELLOW}Średni czas wykonania na test: ${average_time}s${NC}"
echo -e "${YELLOW}Najdłuższy test: $longest_test (Czas: ${longest_time}s)${NC}"
