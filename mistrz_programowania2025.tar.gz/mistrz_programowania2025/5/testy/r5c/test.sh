#!/bin/bash

# Kolory ANSI
GREEN='\033[0;32m'  # Zielony (ZALICZONY)
RED='\033[0;31m'    # Czerwony (NIEZALICZONY)
YELLOW='\033[0;33m' # Żółty (Informacje)
NC='\033[0m'        # Reset kolorów

# Ścieżka do programu i katalogów wejściowych
cpp_file="../../r5c.cpp"
PROGRAM="./a.out"
INPUT_DIR="in"
log_file="test_results.log"

# Inicjalizacja zmiennych
failed_count=0
count=0
total_time=0
longest_time=0
longest_test=""
checker_failed_tests=0

# Funkcja do kompilacji programu
compile_program() {
    echo -e "${YELLOW}Kompilowanie programu...${NC}"
    g++ "$cpp_file" -o "$PROGRAM"
    if [[ $? -ne 0 ]]; then
        echo -e "${RED}Błąd kompilacji. Upewnij się, że kod jest poprawny.${NC}"
        exit 1
    fi
    echo -e "${GREEN}Kompilacja zakończona sukcesem.${NC}"
}

# Kompilacja programu
if [[ -f "$cpp_file" ]]; then
    compile_program
else
    echo -e "${RED}Nie znaleziono pliku $cpp_file.${NC}"
    exit 1
fi

# Wyczyść plik logów
> "$log_file"

# Iteracja przez pliki wejściowe
for input_file in "$INPUT_DIR"/*.in; do
    # Upewnij się, że jest to plik
    if [[ -f "$input_file" ]]; then
        test_num=$(basename "$input_file" .in)
        ((count++))

        # Mierz czas wykonania programu i pamięć
        start_time=$(date +%s.%N)
        output=$(/usr/bin/time -v "$PROGRAM" < "$input_file" 2> time_output.tmp)
        end_time=$(date +%s.%N)

        # Zbieramy dane o czasie wykonania
        elapsed_time=$(echo "$end_time - $start_time" | bc)
        total_time=$(echo "$total_time + $elapsed_time" | bc)

        # Zbieramy dane o zużyciu pamięci
        memory_used=$(grep "Maximum resident set size" time_output.tmp | awk '{print $6}')

        # Aktualizuj najdłuższy czas
        if (( $(echo "$elapsed_time > $longest_time" | bc -l) )); then
            longest_time=$elapsed_time
            longest_test=$test_num
        fi

        # Zapisz wynik testu
        echo -e "\nUruchamiam checker dla testu $test_num"
        checker_input="$output"
        checker_result=$(echo "$checker_input" | ./checker 2>&1)

        if [[ "$checker_result" == *"C"* ]]; then
            echo -e "${GREEN}Checker: ZALICZONY${NC} (Czas: ${elapsed_time}s, Pamięć: ${memory_used} KB)"
            echo "Test $test_num: ZALICZONY (Czas: ${elapsed_time}s, Pamięć: ${memory_used} KB)" >> "$log_file"
        else
            echo -e "$checker_result"
            echo -e "${RED}Checker: NIEZALICZONY${NC} (Czas: ${elapsed_time}s, Pamięć: ${memory_used} KB)"
            echo "Test $test_num: NIEZALICZONY (Czas: ${elapsed_time}s, Pamięć: ${memory_used} KB)" >> "$log_file"
            ((checker_failed_tests++))
        fi
    fi
done

# Oblicz średni czas wykonania
if (( count > 0 )); then
    average_time=$(echo "$total_time / $count" | bc -l)
else
    average_time=0
fi

# Podsumowanie
{
    echo -e "${YELLOW}Podsumowanie:${NC}"
    echo "Liczba testów: $count"
    echo "Nieudane testy (checker): $checker_failed_tests"
    echo "Zaliczone testy: $((count - checker_failed_tests))"
    echo "Średni czas wykonania: ${average_time}s"
    echo "Najdłuższy czas: ${longest_time}s (Test: $longest_test)"
} | tee -a "$log_file"

# Usuń tymczasowy plik z wynikami
rm -f time_output.tmp
