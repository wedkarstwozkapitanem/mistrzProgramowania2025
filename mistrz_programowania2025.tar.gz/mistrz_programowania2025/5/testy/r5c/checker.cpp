#include <iostream>

using namespace std;

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    unsigned int wagony;
    cin >> wagony;
    
    unsigned long long pomiary[wagony];
    for(unsigned int i=0; i<wagony-1; i++) {
		cin >> pomiary[i];
	}
	
	string exp;
    cin >> exp;
	
	string odp;
    cin >> odp;
    
    if(odp != exp){
        cout << "I: źle określono błąd - powinno być " << exp;
        return 0;
    }
    
    if(odp=="Nie"){
		cout << "C";
		return 0;
	}
    
    unsigned long long prev, next;
    cin >> prev;
    for(unsigned int i=1; i<wagony; i++) {
		cin >> next;
		
		if(pomiary[i-1] != prev+next) {
			cout << "I: źle określono wagę";
			return 0;
		}
		
		prev = next;
	}
	
	
	
    cout << "C";
    return 0;
}
