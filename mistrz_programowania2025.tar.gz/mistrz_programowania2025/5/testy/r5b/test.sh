#!/bin/bash

# Kompilacja programu C++ z katalogu nadrzędnego
cpp_file="../../../r5b.cpp"  # Zmień nazwę na rzeczywistą nazwę pliku

# Kolory
RED='\033[0;31m'      # Czerwony (FAIL)
GREEN='\033[0;32m'    # Zielony (PASS)
YELLOW='\033[0;33m'   # Żółty (informacje)
NC='\033[0m'          # Resetowanie kolorów

# Licznik niepoprawnych wyników
failed_count=0
count=0
total_time=0
longest_time=0
longest_test=""
max_memory=0
max_memory_test=""
log_file="test_results.log"

show_diffs=true

binary_file="./program.out"

if [[ -f "$cpp_file" ]]; then
    echo -e "${YELLOW}Kompilowanie programu...${NC}"
    g++ "$cpp_file" -o "$binary_file"
    if [[ $? -ne 0 ]]; then
        echo -e "${RED}Błąd kompilacji. Upewnij się, że kod jest poprawny.${NC}"
        exit 1
    fi
    echo -e "${GREEN}Kompilacja zakończona sukcesem.${NC}"
else
    echo -e "${RED}Nie znaleziono pliku $cpp_file.${NC}"
    exit 1
fi

# Wyczyść plik logów
> "$log_file"

# Funkcja do normalizacji tekstu (usunięcie nadmiarowych białych znaków)
normalize() {
    echo "$1" | tr -s '[:space:]' ' ' | sed 's/^ //;s/ $//' | tr '\n' ' '
}

# Znajdź wszystkie pliki wejściowe *.in
for test_in in in/*.in; do
    test_num=${test_in%.in}  # Usuń rozszerzenie .in, aby uzyskać numer
    test_num=$(basename "$test_in" .in)  # Usuwamy rozszerzenie .in, ale nadal mamy "in/10007"
    test_num=out/${test_num#in/}  # Usuwamy część "in/" z początku, zostaje tylko "10007"

    ((count++))

    # Zmierz czas i pamięć wykonania programu
    start_time=$(date +%s.%N)
    # Osobno przechwyć wyjście programu i pomiar pamięci
    program_output=$("$binary_file" < "$test_in")
    memory_used=$( ( /usr/bin/time -f "%M" "$binary_file" < "$test_in" >/dev/null ) 2>&1 )
    end_time=$(date +%s.%N)

    elapsed_time=$(echo "$end_time - $start_time" | bc)
    total_time=$(echo "$total_time + $elapsed_time" | bc)

    # Aktualizuj największe zużycie pamięci
    if (( memory_used > max_memory )); then
        max_memory=$memory_used
        max_memory_test=$test_num
    fi

    # Sprawdź, czy to najdłuższy czas
    if (( $(echo "$elapsed_time > $longest_time" | bc -l) )); then
        longest_time=$elapsed_time
        longest_test=$test_num
    fi

    # Porównaj wyniki po normalizacji
    expected_output=$(cat "${test_num}.out")
    normalized_expected=$(normalize "$expected_output")
    normalized_output=$(normalize "$program_output")

    if [[ "$normalized_output" == "$normalized_expected" ]]; then
        echo -e "Test $test_num: ${GREEN}ZALICZONY ${NC} (Czas: ${elapsed_time}s, Pamięć: ${memory_used} kB)"
        echo "Test $test_num: ZALICZONY (Czas: ${elapsed_time}s, Pamięć: ${memory_used} kB)" >> "$log_file"
    else
        echo -e "Test $test_num: ${RED}NIEZALICZONY${NC} (Czas: ${elapsed_time}s, Pamięć: ${memory_used} kB)"
        echo "Test $test_num: NIEZALICZONY (Czas: ${elapsed_time}s, Pamięć: ${memory_used} kB)" >> "$log_file"
        ((failed_count++))
        if $show_diffs; then
            echo "Różnice dla testu $test_num:" >> "$log_file"
            diff <(echo "$normalized_expected") <(echo "$normalized_output") >> "$log_file"
        fi
    fi
done

# Wyświetl podsumowanie
average_time=$(echo "$total_time / $count" | bc -l)

echo -e "${YELLOW}Łączna liczba testów: $count${NC}"
echo -e "${RED}Nieudane testy: $failed_count${NC}"
echo -e "${GREEN}Zaliczone testy: $((count - failed_count))${NC}"
echo -e "${YELLOW}Łączny czas wykonania: ${total_time}s${NC}"
echo -e "${YELLOW}Średni czas wykonania na test: ${average_time}s${NC}"
echo -e "${YELLOW}Najdłuższy test: Test $longest_test (Czas: ${longest_time}s)${NC}"
echo -e "${YELLOW}Największe użycie pamięci: ${max_memory} kB (Test: $max_memory_test)${NC}"

# Podsumowanie do pliku
{
    echo "Łączna liczba testów: $count"
    echo "Nieudane testy: $failed_count"
    echo "Zaliczone testy: $((count - failed_count))"
    echo "Łączny czas wykonania: ${total_time}s"
    echo "Średni czas wykonania na test: ${average_time}s"
    echo "Najdłuższy test: Test $longest_test (Czas: ${longest_time}s)"
    echo "Największe użycie pamięci: ${max_memory} kB (Test: $max_memory_test)"
} >> "$log_file"
