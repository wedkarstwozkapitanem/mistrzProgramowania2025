#include<iostream>
#include<time.h>

int main() {
    std::srand(time(NULL));
    unsigned long long n = 10e18;
    std::cout << n << '\n';
    for(int i{};i<n;++i){
        std::cout << i;
    }

}