#include <iostream>
#include <vector>
#include <algorithm>



bool czy_posortowane(const std::vector<int>& p) {
    for (size_t i = 1; i < p.size(); i++) {
        if (p[i - 1] > p[i]) return false;
    }
    return true;
}

void gra() {
    int n, s;
    std::cin >> n >> s;
    s--; 


    std::vector<std::vector<int>> drzewo(n); 


    for (int i = 0; i < n - 1; i++) {
        int a, b;
        std::cin >> a >> b;
        a--, b--; 
        drzewo[a].push_back(b);
        drzewo[b].push_back(a);
    }

    std::vector<int> permutacje(n);
    for (int i = 0; i < n; i++) {
        std::cin >> permutacje[i];
        permutacje[i]--; 
    }


    for (int turn = 0; turn < n; turn++) {
        if (czy_posortowane(permutacje)) {
            std::cout << "M" << '\n'; 
            return;
        }


        int aktualny = s;


        bool ruch = false;
        for (int i = 0; i < n && !ruch; i++) {
            for (int j = i + 1; j < n && !ruch; j++) {
                if (i != aktualny && j != aktualny) {
                    std::swap(permutacje[i], permutacje[j]);
                    ruch = true;
                }
            }
        }

        if (!ruch) {
            std::cout << "J" << '\n';
            return;
        }


        for (int x : drzewo[s]) {
            s = x;
            break;
        }
    }


    std::cout << "J" << '\n';
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    gra();

    return 0;
}
