#include <iostream>
#include <vector>
#include <random>
#include <chrono>

// Generator dla najgorszego przypadku - maksymalna plansza z dużą liczbą możliwych ścieżek
void generuj_duzy_labirynt() {
    const int n = 1000;
    const int m = 1000;
    std::cout << n << " " << m << "\n";
    
    // Początek w lewym górnym rogu, meta w prawym dolnym
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            if(i == 0 && j == 0) std::cout << 'S';
            else if(i == n-1 && j == m-1) std::cout << 'M';
            else {
                // Generujemy głównie podłogę z okazjonalnymi dziurami
                // ale bez ścian, żeby było dużo możliwych ścieżek
                std::cout << (rand() % 10 == 0 ? '-' : '.');
            }
        }
        std::cout << "\n";
    }
}

// Generator dla przypadku z wieloma ścianami i wąskimi przejściami
void generuj_ciasny_labirynt() {
    const int n = 1000;
    const int m = 1000;
    std::cout << n << " " << m << "\n";
    
    std::vector<std::vector<char>> plansza(n, std::vector<char>(m, '#'));
    
    // Generujemy ścieżkę od startu do mety metodą "wężyka"
    int x = 0, y = 0;
    plansza[0][0] = 'S';
    plansza[n-1][m-1] = 'M';
    
    while(x < n-1 || y < m-1) {
        if(y < m-1 && (x % 2 == 0)) {
            y++;
            plansza[x][y] = '.';
        }
        else if(x < n-1) {
            x++;
            plansza[x][y] = '.';
        }
    }
    
    // Dodajemy losowe dziury obok ścieżki
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            if(plansza[i][j] == '.' && rand() % 5 == 0) {
                if(j+1 < m && plansza[i][j+1] == '#') plansza[i][j+1] = '-';
                if(i+1 < n && plansza[i+1][j] == '#') plansza[i+1][j] = '-';
            }
        }
    }
    
    // Wypisujemy planszę
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            std::cout << plansza[i][j];
        }
        std::cout << "\n";
    }
}

// Generator dla przypadku z długą, jednoznaczną ścieżką
void generuj_dluga_sciezka() {
    const int n = 1000;
    const int m = 1000;
    std::cout << n << " " << m << "\n";
    
    std::vector<std::vector<char>> plansza(n, std::vector<char>(m, '#'));
    
    // Tworzymy spiralną ścieżkę
    int x = 0, y = 0;
    int dx[] = {0, 1, 0, -1};
    int dy[] = {1, 0, -1, 0};
    int kierunek = 0;
    int kroki = 0;
    int max_kroki = m;
    bool zmniejsz = false;
    
    plansza[0][0] = 'S';
    
    while(kroki < n * m) {
        int nx = x + dx[kierunek];
        int ny = y + dy[kierunek];
        
        if(nx >= 0 && nx < n && ny >= 0 && ny < m && plansza[nx][ny] == '#') {
            plansza[nx][ny] = '.';
            x = nx;
            y = ny;
            kroki++;
        } else {
            kierunek = (kierunek + 1) % 4;
            if(zmniejsz) max_kroki--;
            zmniejsz = !zmniejsz;
        }
    }
    
    // Ustawiamy metę na końcu ścieżki
    plansza[x][y] = 'M';
    
    // Wypisujemy planszę
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            std::cout << plansza[i][j];
        }
        std::cout << "\n";
    }
}

int main() {
    std::srand(std::time(nullptr));
    
    std::cout << "Generowanie testu 1: Duży labirynt z wieloma ścieżkami\n";
    generuj_duzy_labirynt();
    
    std::cout << "\nGenerowanie testu 2: Ciasny labirynt\n";
    generuj_ciasny_labirynt();
    
    std::cout << "\nGenerowanie testu 3: Długa, jednoznaczna ścieżka\n";
    generuj_dluga_sciezka();
    
    return 0;
}