/*
*    nazwa: Prostopadłościan
*    autor: Dominik Łempicki Kapitan
*/

#include <iostream>
#include <vector>
#include <queue>
#include <limits>

struct kratka {
    char pole{'-'};
    bool czyOdwiedzone[3] = {false,false,false};
};

struct doOdwiedzeniaPola {
    int x, y, licznikOperacji{};
    short ktorastrona{0};
};

short POCZOTKOWY_STAN{};

inline std::pair<int,int> wczytajPlansze(std::vector<std::vector<kratka>> &plansza) {
    int x,y;
    bool czyZnaleziono{false};
    for (int i{1}; i < plansza.size() - 1; ++i) {
        bool czywlini{false};
        for (int j{1}; j < plansza[0].size() - 1; ++j) {
            std::cin >> plansza[i][j].pole;
            if(plansza[i][j].pole=='S') {
                if(!czywlini && !czyZnaleziono) {
                    x = i;
                    y = j;
                    czywlini = true;
                    czyZnaleziono = true;
                } else if(czywlini) POCZOTKOWY_STAN = 1;
                else POCZOTKOWY_STAN = 2;  
            }
        }
    }
    return std::make_pair(x,y);
}

void wyswietl(const std::vector<std::vector<kratka>> &plansza) {
    for (const auto &i : plansza) {
        for (const auto &j : i) std::cout << j.pole;
        std::cout << '\n';
    }

std::cout << '\n';
    for (const auto &i : plansza) {
        for (const auto &j : i) std::cout << j.czyOdwiedzone[0]<< j.czyOdwiedzone[1] << j.czyOdwiedzone[2] << ' ';
        std::cout << '\n';
    }

    std::cout << '\n';
}

inline bool czywplanszy(const int x, const int y, const int n, const int m) {
    return (x >= 0 && y >= 0 && x < n && y < m);
}

inline bool czyMoznaStawiac(const std::vector<std::vector<kratka>> &plansza,const int x,const int y,const short orientacja) {
    if(orientacja==0) return plansza[x][y].pole == '.' || plansza[x][y].pole == 'M';
    else if(orientacja == 1) {
        if(plansza[x][y].pole =='.' && plansza[x][y+1].pole == '.') return true;
        else if((plansza[x][y].pole =='.' && plansza[x][y+1].pole == '-') || (plansza[x][y].pole =='-' && plansza[x][y+1].pole == '.')|| (plansza[x][y].pole =='M' && plansza[x][y+1].pole == '.') || (plansza[x][y].pole =='.' && plansza[x][y+1].pole == 'M')) return true;
        return false;
    } else if(orientacja == 2) {
        if(plansza[x][y].pole =='.' && plansza[x+1][y].pole == '.') return true;
        else if((plansza[x][y].pole =='.' && plansza[x+1][y].pole == '-') || (plansza[x][y].pole =='-' && plansza[x+1][y].pole == '.')|| (plansza[x][y].pole =='M' && plansza[x+1][y].pole == '.') || (plansza[x][y].pole =='.' && plansza[x+1][y].pole == 'M')) return true;
        return false;
    }
    return false;
}

int bfs(std::vector<std::vector<kratka>> &plansza, const int n, const int m, int startX, int startY) {
    int wynik = std::numeric_limits<int>::max();

    std::queue<doOdwiedzeniaPola> doPrzetworzenia;


    doPrzetworzenia.push({startX, startY, 0,POCZOTKOWY_STAN});

    int licznik{};
    while (!doPrzetworzenia.empty()) {
    
        const auto aktualny = doPrzetworzenia.front();
        doPrzetworzenia.pop();
        if(plansza[aktualny.x][aktualny.y].czyOdwiedzone[aktualny.ktorastrona]) continue;

        plansza[aktualny.x][aktualny.y].czyOdwiedzone[aktualny.ktorastrona] = true;

        /*
            0 -> pionowo
            1 -> prawo 
            2 -> dol
            3 -> lewo
        */
        int x{aktualny.x},y{aktualny.y};

        if(aktualny.ktorastrona==0) {
            if(plansza[aktualny.x][aktualny.y].pole == 'M') wynik = std::max(wynik,aktualny.licznikOperacji);
            if(czywplanszy(x+2,y,n,m) && czyMoznaStawiac(plansza,x+1,y,2)) doPrzetworzenia.push({x+1,y,aktualny.licznikOperacji+1,2});
            if(czywplanszy(x-2,y,n,m) && czyMoznaStawiac(plansza,x-2,y,2)) doPrzetworzenia.push({x-2,y,aktualny.licznikOperacji+1,2});
            if(czywplanszy(x,y+2,n,m) && czyMoznaStawiac(plansza,x,y+1,1)) doPrzetworzenia.push({x,y+1,aktualny.licznikOperacji+1,1});
            if(czywplanszy(x,y-2,n,m) && czyMoznaStawiac(plansza,x,y+1,1)) doPrzetworzenia.push({x,y-2,aktualny.licznikOperacji+1,1});

        } else if(aktualny.ktorastrona == 1) {
            if(czywplanszy(x,y+1,n,m) && czyMoznaStawiac(plansza,x,y+1,0)) doPrzetworzenia.push({x,y+1,aktualny.licznikOperacji+1,0});
            if(czywplanszy(x,y-1,n,m) && czyMoznaStawiac(plansza,x,y-1,0)) doPrzetworzenia.push({x,y-1,aktualny.licznikOperacji+1,0});
            if(czywplanszy(x+2,y,n,m) && czyMoznaStawiac(plansza,x+1,y,1)) doPrzetworzenia.push({x+1,y,aktualny.licznikOperacji+1,1});
            if(czywplanszy(x-2,y,n,m) && czyMoznaStawiac(plansza,x-2,y,1)) doPrzetworzenia.push({x-2,y,aktualny.licznikOperacji+1,1});

        } else if(aktualny.ktorastrona == 2) {
            if(czywplanszy(x-1,y,n,m)  && czyMoznaStawiac(plansza,x-1,y,0)) doPrzetworzenia.push({x-1,y,aktualny.licznikOperacji+1,0});
            if(czywplanszy(x+1,y,n,m)  && czyMoznaStawiac(plansza,x+1,y,0)) doPrzetworzenia.push({x+1,y,aktualny.licznikOperacji+1,0});
            if(czywplanszy(x,y-2,n,m) && czyMoznaStawiac(plansza,x,y-2,2)) doPrzetworzenia.push({x,y-2,aktualny.licznikOperacji+1,2});
            if(czywplanszy(x,y+2,n,m) && czyMoznaStawiac(plansza,x,y+1,2)) doPrzetworzenia.push({x,y+1,aktualny.licznikOperacji+1,2});
        }
 
        //std::cout << aktualny.licznikOperacji << '\n';
    }

    return wynik != std::numeric_limits<int>::max() ? wynik : -1;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<kratka>> plansza(n + 2, std::vector<kratka>(m + 2));

    const auto start = wczytajPlansze(plansza);

    
    std::cout << bfs(plansza, n+2, m+2, start.first+1, start.second+1) << '\n';
    wyswietl(plansza);

    return 0;
}  