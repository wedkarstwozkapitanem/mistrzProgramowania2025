/*
*    nazwa: Pomiary
*    autor: Dominik Łempicki Kapitan
*/

#include <iostream>
#include <vector>

const long long MAX = 1'000'000'000;

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    long long n;
    std::cin >> n;
    std::vector<long long> wagiWagonow(n);

    std::cin >> wagiWagonow[0];
    for (int i = 1; i < n - 1; ++i) {
        long long wagon{};
        std::cin >> wagon;
        wagiWagonow[i + 1] = wagon - wagiWagonow[i];
        if (wagiWagonow[i + 1] < 0 || wagiWagonow[i + 1] > MAX) { 
            std::cout << "Nie\n";
            return 0;
        }
    }

    std::cout << "Tak\n";
    for (const auto& i : wagiWagonow) std::cout << i << " ";
    
    std::cout << "\n";

    return 0;
}