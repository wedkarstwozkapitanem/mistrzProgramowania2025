/*
*    nazwa: Patrol
*    autor: Dominik Łempicki Kapitan
*/

#include <iostream>
#include <cstring>

inline int wczytywanie(char*& buffer, size_t& rozmiar) {
    rozmiar = 0;
    size_t pojemnosc = 16;
    buffer = (char*)malloc(pojemnosc * sizeof(char)); 
    char c;
    while (true) {
        c = getchar_unlocked();
        if (c == '\n' || c == EOF) break;
        if (rozmiar + 1 >= pojemnosc) {
            pojemnosc *= 2; 
            buffer = (char*)realloc(buffer, pojemnosc * sizeof(char));
        }
        buffer[rozmiar++] = c;
    }
    buffer[rozmiar] = '\0';
    return rozmiar;
}

inline void drukuj(const char* buffer, size_t rozmiar) {
    for (size_t i = 0; i < rozmiar; ++i) putchar_unlocked(buffer[i]);
    putchar_unlocked('\n');
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    
    char* liczba = nullptr;
    size_t n;
    wczytywanie(liczba, n);
    
    if (n == 1) {
        drukuj(liczba, n);
        free(liczba);
        return 0;
    }
    

    bool znaleziono = false;
    char* wynik = (char*)malloc((n + 1) * sizeof(char));
    
    for (char cyfra = liczba[0]; cyfra <= '9' && !znaleziono; ++cyfra) {
        std::memset(wynik, cyfra, n);
        wynik[n] = '\0';
        if (strcmp(wynik, liczba) >= 0) {
            drukuj(wynik, n);
            znaleziono = true;
        }
    }
    
    if (!znaleziono) {
        char* nowy_wynik = (char*)malloc((n + 2) * sizeof(char));
        std::memset(nowy_wynik, '1', n + 1);
        nowy_wynik[n + 1] = '\0';
        drukuj(nowy_wynik, n + 1);
        free(nowy_wynik);
    }
    
    free(wynik);
    free(liczba);
    return 0;
}