/*
*    nazwa: Bajtex S.A.
*    autor: Dominik Łempicki Kapitan
*/

#include "fastio.h"
#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>




class poloczeniaBajtex {
private:
    std::vector<std::pair<int, int>> rodzic; // (rodzic, numer operacji)
    std::vector<int> ranga; 
    std::stack<std::pair<int, int>> operacje;
    int ileOperacji = 0;

public:
    poloczeniaBajtex(const int &n) {
        rodzic.resize(n + 1);
        ranga.resize(n + 1, 0);
        for (int i = 0; i <= n; ++i) {
            rodzic[i] = {i, 0}; // Każdy jest swoim rodzicem, brak operacji na początku
        }
    }

    inline int znajdz(const int &n) {
        if (rodzic[n].first == n) return n;
        return rodzic[n].first = znajdz(rodzic[n].first); // Kompresja ścieżki
    }

    inline void polocz(const int &x, const int &y) {
        ++ileOperacji;
        int rootX = znajdz(x);
        int rootY = znajdz(y);

        if (rootX != rootY) {
            if (ranga[rootX] > ranga[rootY]) {
                rodzic[rootY] = {rootX, ileOperacji};
            } else if (ranga[rootX] < ranga[rootY]) {
                rodzic[rootX] = {rootY, ileOperacji};
            } else {
                rodzic[rootY] = {rootX, ileOperacji};
                ++ranga[rootX];
            }
            operacje.push({rootY, rootX}); // Zapisujemy operację
        }
    }

    inline void cofnij(int &k) {
        while (k-- > 0 && !operacje.empty()) {
            auto ostatniaZmiana = operacje.top();
            operacje.pop();
            rodzic[ostatniaZmiana.first].first = ostatniaZmiana.second;
        }
    }

    inline int ileOperacjiCofniecia(const int &x, const int &y) {
        if (znajdz(x) != znajdz(y)) return 0;
        return std::min(rodzic[znajdz(x)].second, rodzic[znajdz(y)].second);
    }
};

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, m;
    wczytaj_nm(n, m); // Funkcja wczytująca n i m
    poloczeniaBajtex bajtex(n);

    char zapytanie{};
    int x{}, y{};
    for (int i = 0; i < m; ++i) {
        wczytaj_zapytanie(zapytanie, x, y); // Funkcja wczytująca zapytanie
        if (zapytanie == 'P') {
            bajtex.polocz(x - 1, y - 1); // Indeksy od zera
        } else if (zapytanie == 'Z') {
            int wynik = bajtex.ileOperacjiCofniecia(x - 1, y - 1);
            wypisz(wynik); // Funkcja wypisująca wynik
        } else if (zapytanie == 'C') {
            bajtex.cofnij(x);
        }
    }

    return EXIT_SUCCESS;
}



/*
*    nazwa: Bajtex S.A.
*    autor: Dominik Łempicki Kapitan
*/

#include "fastio.h"
#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

class PoloczeniaBajtex {
private:
    std::vector<int> rodzice, rangi;
    std::stack<std::pair<int,int>> historia;
    std::stack<std::pair<int,int>> historia2;
    int ilePoloczen{};
    
    int znajdz(int pracownik) {
        if (rodzice[pracownik] == pracownik) return pracownik;
        return rodzice[pracownik] = znajdz(rodzice[pracownik]);
    }

    void polacz_z_ranga(int x, int y) {
        
        historia2.push({x,rodzice[x]});
        historia2.push({y,rodzice[y]});
        
        int px = znajdz(x);
        int py = znajdz(y);
        
        if (px != py) {
            if (rangi[px] < rangi[py]) std::swap(px, py);
 
            rodzice[py] = px;
            if (rangi[px] == rangi[py]) rangi[px]++;
        }
    }


    inline void cofnijOstatnioOperacje() {
        for(int i{};i<2;++i) {
            const auto ostatniaOperacja = historia2.top();
            historia2.pop();
            rodzice[ostatniaOperacja.first] = ostatniaOperacja.second;
        }
    }

public:
    PoloczeniaBajtex(const int &n) {
        rodzice.resize(n + 1);
        rangi.resize(n + 1, 0);
        for(int i = 0; i <= n; ++i) rodzice[i] = i;
    }

    inline void polocz(const int &pracownikX, const int &pracownikY) {
        ++ilePoloczen;
        polacz_z_ranga(pracownikX, pracownikY);
        historia.push({pracownikX, pracownikY}); 
    }



    inline void cofnij(const int &k) {
        for(int i{};i<k;++i) cofnijOstatnioOperacje();
    }

    inline void policzIleCofniec(const int skarzepyt, const int doWywalenia) {
        if (znajdz(skarzepyt) != znajdz(doWywalenia)) {
            wypisz(0);
            return;
        }
        
        std::vector<int> temp_rodzice = rodzice;
        std::vector<int> temp_rangi = rangi;
        std::stack<std::pair<int,int>> temp_historia = historia;
        
        int wynik = 0;
        while (!temp_historia.empty() && znajdz(skarzepyt) == znajdz(doWywalenia)) {
            temp_historia.pop();
            ++wynik;
            
            for(size_t i = 0; i < rodzice.size(); ++i) {
                rodzice[i] = i;
                rangi[i] = 0;
            }
            
            std::stack<std::pair<int,int>> temp = temp_historia;
            while(!temp.empty()) {
                auto [x, y] = temp.top();
                polacz_z_ranga(x, y);
                temp.pop();
            }
        }
        
        rodzice = temp_rodzice;
        rangi = temp_rangi;
        
         (wynik <= historia.size()) ? wypisz(wynik) : wypisz(-1);
    }
};

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n,m;
    wczytaj_nm(n,m);

    PoloczeniaBajtex firmaBajtex(n);

    for (int i = 0; i < m; ++i) {
        char zapytanie;
        int x,y;
        wczytaj_zapytanie(zapytanie,x,y);

        if(zapytanie == 'P') firmaBajtex.polocz(x,y);
        else if(zapytanie == 'C') firmaBajtex.cofnij(x);
        else if(zapytanie == 'Z') firmaBajtex.policzIleCofniec(x,y);
    }

    return EXIT_SUCCESS;
}
