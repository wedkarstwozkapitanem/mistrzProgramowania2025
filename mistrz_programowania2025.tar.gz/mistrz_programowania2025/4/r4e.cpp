#include "fastio.h"
#include <iostream>
#include <vector>
#include <stack>

class findandunion {
private:
    std::vector<int> rodzice;
    std::vector<int> ranga;
    
public:
    findandunion(int n) : rodzice(n + 1), ranga(n + 1, 0) {
        for(int i = 0; i <= n; i++) rodzice[i] = i;
    }
    
    inline int znajdz(int x) {
        if(rodzice[x] == x) return x;
        return rodzice[x] = znajdz(rodzice[x]);
    }
    
    inline void polocz(int x, int y) {
        int px = znajdz(x);
        int py = znajdz(y);
        
        if(px != py) {
            if(ranga[px] < ranga[py])
                std::swap(px, py);
                
            rodzice[py] = px;
            if(ranga[px] == ranga[py])
                ranga[px]++;
        }
    }
    
    inline bool poloczone(int x, int y) {
        return znajdz(x) == znajdz(y);
    }
    

    findandunion(const findandunion& other) : rodzice(other.rodzice), ranga(other.ranga) {}
    
    inline void reset() {
        for(size_t i = 0; i < rodzice.size(); i++) {
            rodzice[i] = i;
            ranga[i] = 0;
        }
    }
};

struct Operation {
    int x, y;
};

class PoloczeniaBajtex {
private:
    findandunion dane;
    std::vector<Operation> operacje;
    int n;
    
public:
    PoloczeniaBajtex(int size) : dane(size), n(size) {}
    
    void polocz(int x, int y) {
        operacje.push_back({x, y});
        dane.polocz(x, y);
    }
    
    void cofnij(int k) {
        k = std::min(k, (int)operacje.size());
        operacje.resize(operacje.size() - k);
        
        dane.reset();
        for(const auto& op : operacje) dane.polocz(op.x, op.y);
    }
    
    void policzIleCofniec(int x, int y) {
        if(!dane.poloczone(x, y)) {
            wypisz(0);
            return;
        }
        

        for(int k = 1; k <= operacje.size(); k++) {
            findandunion tmp_dane(n);
          
            for(size_t i = 0; i < operacje.size() - k; i++)  tmp_dane.polocz(operacje[i].x, operacje[i].y);
            
            if(!tmp_dane.poloczone(x, y)) {
                wypisz(k);
                return;
            }
        }
        
        wypisz(-1);
    }
};

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    
    int n, m;
    wczytaj_nm(n, m);
    
    PoloczeniaBajtex firma(n);
    
    for(int i = 0; i < m; i++) {
        char typ;
        int x, y;
        wczytaj_zapytanie(typ, x, y);
        
        if(typ == 'P') firma.polocz(x, y);
        else if(typ == 'C') firma.cofnij(x);
        else  firma.policzIleCofniec(x, y);
        
    }
    
    return EXIT_SUCCESS;
}