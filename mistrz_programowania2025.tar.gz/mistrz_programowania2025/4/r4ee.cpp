/*
*    nazwa: Bajtex S.A.
*    autor: Dominik Łempicki Kapitan
*/

#include "fastio.h"
#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

class PoloczeniaBajtex {
private:
    struct przyloczonyPokoj {
        int numer{},id{};
    };
    std::vector<int> rangi;
    std::vector<przyloczonyPokoj> rodzice;

    std::stack<std::pair<int,int>> historia;
    int ilePoloczen{};
    
    int znajdz(int pracownik) {
        if (rodzice[pracownik].numer == pracownik) return pracownik;
        return rodzice[pracownik].numer = znajdz(rodzice[pracownik].numer);
    }

    void polacz_z_ranga(int x, int y) {
        int px = znajdz(x);
        int py = znajdz(y);
        
        if(px == x) rodzice[px].id = ilePoloczen;
        else if(py == y) rodzice[py].id = ilePoloczen;


        if (px != py) {
            if (rangi[px] < rangi[py]) std::swap(px, py);
 
            rodzice[py].numer = px;
           
            if (rangi[px] == rangi[py]) rangi[px]++;
        }
    }

public:
    PoloczeniaBajtex(const int &n) {
        rodzice.resize(n + 1);
        rangi.resize(n + 1, 0);
        for(int i = 0; i <= n; ++i) rodzice[i].numer = i;
    }

    inline void polocz(const int &pracownikX, const int &pracownikY) {
        ++ilePoloczen;
        polacz_z_ranga(pracownikX, pracownikY);
    }

    inline void cofnij(const int &k) {

    }

    inline void policzIleCofniec(const int skarzepyt, const int doWywalenia) {
        const int liderDoWywalenia =  znajdz(doWywalenia);
        if (znajdz(skarzepyt) != liderDoWywalenia) {
            wypisz(0);
            return;
        }
        
        const int ileKrokowSkarzepyt = rodzice[skarzepyt].id,ileKrokowDoWywalenia = rodzice[doWywalenia].id;
        const int wynik = (ilePoloczen - std::max(ileKrokowSkarzepyt,ileKrokowDoWywalenia));
        wypisz(wynik);
    }
};

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n,m;
    wczytaj_nm(n,m);

    PoloczeniaBajtex firmaBajtex(n);

    for (int i = 0; i < m; ++i) {
        char zapytanie;
        int x,y;
        wczytaj_zapytanie(zapytanie,x,y);

        if(zapytanie == 'P') firmaBajtex.polocz(x,y);
        else if(zapytanie == 'C') firmaBajtex.cofnij(x);
        else if(zapytanie == 'Z') firmaBajtex.policzIleCofniec(x,y);
    }

    return EXIT_SUCCESS;
}