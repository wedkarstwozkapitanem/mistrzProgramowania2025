/*
*    nazwa: Gambit wieży
*    autor: Dominik Łempicki Kapitan
*/
#include <iostream>
#include <vector>
#include <array>

const long long MOD = 10e9 + 7;

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    
    int n;
    std::cin >> n;
    int tmp;
    for(int i{};i<3;++i) std::cin >> tmp;

    std::vector<int> wieza(3);
    for(int i{};i<3;++i){
        std::cin >> wieza[i];
    }

    if(wieza[0]==1 && wieza[1]==1 && wieza[2]==1) std::cout << "A\n1";
    else if(wieza[1]==1 && (wieza[0]==1 || wieza[2]==1)) std::cout << "A\n1";
    else std::cout  << "B\n1";
    
    /*std::vector<std::array<bool, 3>> wieza(n);
    bool czyNieTrzy{true};
    bool czyJeden{true};
    
    int p{};
    for(auto &i : wieza) {
        int licznik{};
        for(auto &j : i) {
            std::cin >> j;
            if(j) ++licznik;
        }
        if(p++==0) continue;
        if(licznik > 1) czyJeden = false;
        if(licznik == 3) czyNieTrzy = false;
    }
    
    if(n == 2) {
        if(wieza[1][1] && !wieza[1][0] && !wieza[1][2]) std::cout << "B 1";
        else if(wieza[1][1] && wieza[1][0] && wieza[1][2]) std::cout << "A 1";
        else std::cout << "A 1";
        
        return 0;
    }
    else if(czyJeden) {
        std::cout << "A 1";
    }
    else if(czyNieTrzy) {
        long long ileZBoku{};
        for(int i{1}; i < n; ++i) {
            if(wieza[i][0] || wieza[i][2]) ++ileZBoku;
        }
        if(ileZBoku % 2) {
            std::cout << "A " << (2 * ileZBoku) % MOD;
        }
        else {
            std::cout << "B " << (2 * ileZBoku) % MOD;
        }
    }*/
    
    return EXIT_SUCCESS;
}