#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <set>
#include <sstream>
#include <string>

std::pair<std::string, int> liczby_podzielne_przez(int n, int dzielnik) {
    std::stringstream wynik;
    int liczba_podzielnych = 0;
    for (int i = 1; i <= n; ++i) {
        if (i % dzielnik == 0) {
            if (wynik.tellp() > 0) {
                wynik << " ";
            }
            wynik << i;
            ++liczba_podzielnych;
        }
    }
    return {wynik.str(), liczba_podzielnych};
}

std::pair<std::string, int> liczby_zakresu(int n1, int n2) {
    std::stringstream wynik;
    int liczba_liczb = 0;
    for (int i = n1; i <= n2; ++i) {
        if (wynik.tellp() > 0) {
            wynik << " ";
        }
        wynik << i;
        ++liczba_liczb;
    }
    return {wynik.str(), liczba_liczb};
}

int main() {
    std::ios_base::sync_with_stdio(0);
    std::cin.tie(0);

    int n;
    std::cin >> n;

    std::vector<long long> wynik(n);

    std::cout << "1 1\n" << std::flush;
    long long liczba1, liczba2;
    std::cin >> liczba1;

    std::cout << "1 2\n" << std::flush;
    std::cin >> liczba2;

    std::set<long long> podzielnePrzez[10];
    auto zapytanie = liczby_podzielne_przez(n, 2);
    std::cout << "2 " << zapytanie.first << '\n';

    for (int i{}; i < zapytanie.second * zapytanie.second; ++i) {
        long long tmp;
        std::cin >> tmp;
        podzielnePrzez[2].insert(tmp);
    }

    zapytanie = liczby_podzielne_przez(n, 3);
    std::cout << "2 " << zapytanie.first << '\n';

    for (int i{}; i < zapytanie.second * zapytanie.second; ++i) {
        long long tmp;
        std::cin >> tmp;
        podzielnePrzez[3].insert(tmp);
    }

    zapytanie = liczby_podzielne_przez(n, 4);
    std::cout << "2 " << zapytanie.first << '\n';

    for (int i{}; i < zapytanie.second * zapytanie.second; ++i) {
        long long tmp;
        std::cin >> tmp;
        podzielnePrzez[4].insert(tmp);
    }

    zapytanie = liczby_podzielne_przez(n, 5);
    std::cout << "2 " << zapytanie.first << '\n';

    for (int i{}; i < zapytanie.second * zapytanie.second; ++i) {
        long long tmp;
        std::cin >> tmp;
        podzielnePrzez[5].insert(tmp);
    }

    std::set<long long> zakresu[10];

    int i = n;
    while (i >= 10) {
        zapytanie = liczby_zakresu(i - 10, i);
        std::cout << "2 " << zapytanie.first << '\n';
        if (i > 10) i -= 10;
        else i -= i;

        for (int i{}; i < zapytanie.second * zapytanie.second; ++i) {
            long long tmp;
            std::cin >> tmp;
            zakresu[i / 10].insert(tmp);
        }
    }

    // Szukanie wszystkich miejsc dla danej liczby
    std::cout << "Wszystkie miejsca dla danej liczby:\n";

    // Przechodzimy przez wszystkie liczby w podzielnych przez
    for (int i = 2; i <= 5; ++i) {
        for (const auto& liczba : podzielnePrzez[i]) {
            std::cout << "Liczba: " << liczba << " - Wystąpienia:\n";

            // Szukamy w podzielnePrzez
            std::cout << "  Podzielne przez " << i << ": ";
            bool found = false;
            for (int idx = 0; idx < n; ++idx) {
                if (podzielnePrzez[i].count(liczba)) {
                    std::cout << idx << " ";
                    found = true;
                }
            }
            if (!found) {
                std::cout << "Brak w podzielnePrzez";
            }

            // Szukamy w zakresach
            for (int j = 0; j < 10; ++j) {
                if (zakresu[j].find(liczba) != zakresu[j].end()) {
                    std::cout << "W zakresie " << j << ": ";
                    for (auto& liczba_in_range : zakresu[j]) {
                        if (liczba_in_range == liczba) {
                            std::cout << liczba_in_range << " ";
                        }
                    }
                }
            }
            std::cout << "\n";
        }
    }

    std::cout << "3 ";
    for (const auto& i : wynik) {
        std::cout << i << ' ';
    }

    std::cout << '\n';

    return 0;
}
