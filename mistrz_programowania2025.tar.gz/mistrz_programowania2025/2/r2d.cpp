/*
*    nazwa: Sok z kumkwatu
*    autor: Dominik Łempicki Kapitan
*/

#include <iostream>
#include <vector>

struct Pracownik {
    long long zarobek;     
    long long suma;         
    bool zatrudniony;
    long long ostatniDzien; 
};

int main() {
    std::ios_base::sync_with_stdio(0);
    std::cin.tie(0);

    long long n, q;
    std::cin >> n >> q;

    std::vector<Pracownik> pracownicy(n);
    

    for (int i = 0; i < n; i++) {
        long long wydajnosc;
        std::cin >> wydajnosc;
        pracownicy[i] = {wydajnosc, 0, true, 0};
    }

    for (int qi = 0; qi < q; ++qi) {
        char zadanie;
        std::cin >> zadanie;

        if (zadanie == 'V') {
            long long pracownik, wydajnosc, dzien;
            std::cin >> pracownik >> wydajnosc >> dzien;
            pracownik--;
            
            if (pracownicy[pracownik].zatrudniony) {
                pracownicy[pracownik].suma += pracownicy[pracownik].zarobek * 
                    (dzien - pracownicy[pracownik].ostatniDzien);
            }
            pracownicy[pracownik].zarobek = wydajnosc;
            pracownicy[pracownik].ostatniDzien = dzien;
        }
        else if (zadanie == 'F') {
            long long pracownik, dzien;
            std::cin >> pracownik >> dzien;
            pracownik--;
            
            if (pracownicy[pracownik].zatrudniony) {
                pracownicy[pracownik].suma += pracownicy[pracownik].zarobek * 
                    (dzien - pracownicy[pracownik].ostatniDzien);
            }
            pracownicy[pracownik].zatrudniony = false;
            pracownicy[pracownik].ostatniDzien = dzien;
        }
        else if (zadanie == 'H') {
            long long pracownik, wydajnosc, dzien;
            std::cin >> pracownik >> wydajnosc >> dzien;
            pracownik--;
            
            pracownicy[pracownik].zatrudniony = true;
            pracownicy[pracownik].zarobek = wydajnosc;
            pracownicy[pracownik].suma = 0;
            pracownicy[pracownik].ostatniDzien = dzien;
        }
        else if (zadanie == 'Q') {
            long long l, r, dzien;
            std::cin >> l >> r >> dzien;
            l--; r--;
            
            long long wynik = 0;
            for (int i = l; i <= r; i++) {
                if (pracownicy[i].zatrudniony) {
                    wynik += pracownicy[i].suma + pracownicy[i].zarobek * 
                        (dzien - pracownicy[i].ostatniDzien);
                }
            }
            std::cout << wynik << '\n';
        }
    }

    return 0;
}