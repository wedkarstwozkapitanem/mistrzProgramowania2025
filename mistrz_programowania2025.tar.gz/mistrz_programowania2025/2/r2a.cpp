/*
*    nazwa: Rozmowa kwalifikacyjna
*    autor: Dominik Łempicki Kapitan
*/

#include<iostream>


int main() {
    long long a,b,p;std::cin >> a >> b >> p;
    std::cout << (a*b==p ? "DOBRZE" : "TYLKO SZYBKO"); 
    return EXIT_SUCCESS;
}